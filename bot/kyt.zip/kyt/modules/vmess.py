from kyt import *

#delete
@bot.on(events.CallbackQuery(data=b'delete7-vmess'))
async def delete_vmess(event):
    async def delete_vmess_(event):
        async with bot.conversation(chat) as user:
            # Mendapatkan daftar semua pengguna
            cmd2 = "cat /etc/xray/config.json | grep '^#vmg' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
            z = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)

            # Menampilkan daftar pengguna
            msg = await event.edit(f"""
**LIST ALL USER**
{z}
""", buttons=[[Button.inline("Cancel", b'cancel')]])

            user_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_input = (await user_event).raw_text

            # Menghapus pesan sebelumnya setelah input diterima
            await msg.delete()

        if user_input == "/cancel":
            await event.respond(f"""
**» CANCEL**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            # Menghapus user berdasarkan input
            cmd = f'printf "%s\n" "4" "{user_input}" | m-vmess | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await delete_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'cancel'))
async def cancel(event):
    await event.answer("Operasi dibatalkan.", alert=True)

#renew
@bot.on(events.CallbackQuery(data=b'renew7-vmess'))
async def renew_vmess(event):
    async def renew_vmess_(event):
        async with bot.conversation(chat) as user:
            # Mendapatkan daftar semua pengguna
            cmd2 = "cat /etc/xray/config.json | grep '^#vmg' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
            z = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)

            # Menampilkan daftar pengguna
            msg_user = await event.edit(f"""
**LIST ALL USER**
{z}
""", buttons=[[Button.inline("Cancel", b'cancel')]])

            user_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_input = (await user_event).raw_text

            # Menghapus pesan yang menampilkan daftar pengguna
            await msg_user.delete()

        if user_input == "/cancel":
            await event.respond(f"""
**» CANCEL**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            async with bot.conversation(chat) as exp:
                msg_exp = await event.respond(f"""
**Input Your New Expired (day) :**
""")
                exp_event = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp_input = (await exp_event).raw_text

            # Menghapus pesan yang meminta input expired
            await msg_exp.delete()

            # Mengupdate expired dengan input pengguna
            cmd = f'printf "%s\n" "3" "{user_input}" "{exp_input}" | m-vmess | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await renew_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'cancel'))
async def cancel(event):
    await event.answer("Operasi dibatalkan.", alert=True)

#limit
@bot.on(events.CallbackQuery(data=b'limit7-vmess'))
async def limit_vmess(event):
    async def limit_vmess_(event):
        async with bot.conversation(chat) as user:
            # Mendapatkan daftar pengguna
            cmd2 = "cat /etc/xray/config.json | grep '^#vmg' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
            z = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)

            # Menampilkan daftar pengguna
            msg_user = await event.edit(f"""
**CHANGE LIMIT USER**
{z}
""", buttons=[[Button.inline("Cancel", b'cancel')]])

            user_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_input = (await user_event).raw_text

            # Menghapus pesan yang menampilkan daftar pengguna
            await msg_user.delete()

        if user_input == "/cancel":
            await event.respond(f"""
**» CANCEL**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            async with bot.conversation(chat) as exp:
                msg_exp = await event.respond(f"""
**Input Your New Limit IP Login :**
""")
                exp_event = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp_input = (await exp_event).raw_text

            # Menghapus pesan yang meminta input limit IP
            await msg_exp.delete()

            async with bot.conversation(chat) as pw:
                msg_pw = await event.respond(f"""
**Input Your New Quota User :**
""")
                pw_event = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw_input = (await pw_event).raw_text

            # Menghapus pesan yang meminta input quota user
            await msg_pw.delete()

            # Menjalankan perintah untuk mengupdate limit dan quota
            cmd = f'printf "%s\n" "7" "{user_input}" "{exp_input}" "{pw_input}" | m-vmess | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await limit_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'cancel'))
async def cancel(event):
    await event.answer("Operasi dibatalkan.", alert=True)

#CekConfig
@bot.on(events.CallbackQuery(data=b'akun7-vmess'))
async def akun_vmess(event):
    async def akun_vmess_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/xray/config.json | grep '^#vmg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**CEK CONFIG USER**
{z}
""", buttons=[[Button.inline("Cancel", b'menu')]])
            
            user_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_input = (await user_event).raw_text

        if user_input == "/cancel":
            await event.respond(f"**» CANCEL**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            cmd = f'printf "%s\n" "6" "{user_input}" | m-vmess | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await akun_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)
		
#restore
@bot.on(events.CallbackQuery(data=b'restore7-vmess'))
async def restore_vmess(event):
	async def restore_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vmess/akundelete | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			msg = await event.edit(f"""
**LIST AKUN RESTORE**
{z}
**Input Your Number :**
""", buttons=[[Button.inline("Cancel", b'cancel')]])
			
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
			
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		else:
			# Menghapus pesan yang ada sebelum menampilkan input baru
			await msg.delete()
			async with bot.conversation(chat) as exp:
				msg = await event.respond(f"""
**Input Your Expired (day) :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			# Menghapus pesan input expired
			await msg.delete()
			async with bot.conversation(chat) as pw:
				msg = await event.respond(f"""
**Input Your New Limit IP Login :**
""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			# Menghapus pesan input limit IP Login
			await msg.delete()
			async with bot.conversation(chat) as pw2:
				msg = await event.respond(f"""
**Input Your New Quota User:**
""")
				pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw2 = (await pw2).raw_text
			# Menghapus pesan input quota user
			await msg.delete()

			cmd = f'printf "%s\n" "11" "{user}" "{exp}" "{pw}" "{pw2}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)

	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await restore_vmess_(event)
	else:
		await event.answer("Akses Ditolak", alert=True)

#MultiLogin Login
@bot.on(events.CallbackQuery(data=b'loginip7-vmess'))
async def loginip_vmess(event):
	async def loginip_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vmess/listlock | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**LIST MULTI LOGIN IP USER**
{z}
**Input Your Number :**
/cancel Untuk Kembali
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" "9" "{user}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES UNLOCK**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await loginip_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
#MultiLogin Quota
@bot.on(events.CallbackQuery(data=b'logingb7-vmess'))
async def logingb_vmess(event):
	async def logingb_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vmess/userQuota | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**LIST LOGIN QUOTA USER**
{z}
**Input Your Number :**
/cancel Untuk Kembali
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" "10" "{user}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES UNLOCK**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await logingb_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
#CRATE VMESS

from telethon import Button

@bot.on(events.CallbackQuery(data=b'create7-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        async with bot.conversation(chat) as user_conv:
            msg_user = await event.edit("**Input UserName :**")
            user_message = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user_message.raw_text
            await msg_user.delete()  # Hapus pesan UserName setelah input
        
        if user == "/cancel":
            await event.respond("**» CANCEL**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            return

        exp = await get_expiration(event, chat)
        if exp is None:
            return

        pw = await get_limit_ip(event, chat)
        if pw is None:
            return

        pw2 = await get_quota_user(event, chat)
        if pw2 is None:
            return

        try:
            cmd = f'printf "%s\n" "1" "{user}" "{exp}" "{pw}" "{pw2}" | m-vmess | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError as e:
            await event.respond(f"**Error:** {str(e)}", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    async def get_expiration(event, chat):
        async with bot.conversation(chat) as exp_conv:
            buttons = [
                [Button.inline("5 hari", b'5')],
                [Button.inline("10 hari", b'10')],
                [Button.inline("15 hari", b'15')],
                [Button.inline("20 hari", b'20')],
                [Button.inline("25 hari", b'25')],
                [Button.inline("30 hari", b'30')],
                [Button.inline("Input Manual", b'manual')]
            ]
            msg_exp = await event.respond("**Input Your Expired (day)**", buttons=buttons)
            response = await exp_conv.wait_event(events.CallbackQuery)
            
            if response.data == b'manual':
                await msg_exp.delete()  # Hapus pesan tombol
                msg_manual = await exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = msg_manual.raw_text
                await msg_manual.delete()  # Hapus pesan input manual
            else:
                exp = response.data.decode()  # Ambil nilai dari tombol yang ditekan
            
            await msg_exp.delete()  # Hapus pesan pilihan setelah input
            return exp

    async def get_limit_ip(event, chat):
        async with bot.conversation(chat) as pw_conv:
            buttons = [[Button.inline(str(i), str(i).encode()) for i in range(1, 11)]] + [[Button.inline("Input Manual", b'manual')]]
            msg_pw = await event.respond("**Input Your Limit IP Login**", buttons=buttons)
            
            response = await pw_conv.wait_event(events.CallbackQuery)
            
            if response.data == b'manual':
                await msg_pw.delete()  # Hapus pesan tombol
                msg_manual = await pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw = msg_manual.raw_text
                await msg_manual.delete()  # Hapus pesan input manual
            else:
                pw = response.data.decode()  # Ambil nilai dari tombol yang ditekan
            
            await msg_pw.delete()  # Hapus pesan pilihan setelah input
            return pw

    async def get_quota_user(event, chat):
        async with bot.conversation(chat) as pw2_conv:
            msg_pw2 = await event.respond("**Input Your Quota User**\n0 For Unlimited")
            pw2_message = await pw2_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            await msg_pw2.delete()  # Hapus pesan Quota setelah input
            return pw2_message.raw_text

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


# TRIAL VMES
@bot.on(events.CallbackQuery(data=b'trial7-vmess'))
async def trial_vmess(event):
	async def trial_vmess_(event):
		async with bot.conversation(chat) as exp:
			await event.edit(f"""
**Input Your Minutes (Hanya Angka) :**
/cancel Untuk Kembali
""")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		per = "/cancel"
		if exp == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" {2} "{exp}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True).decode("utf-8")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CEK
@bot.on(events.CallbackQuery(data=b'cek7-vmess'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		cmd = 'bot-cek-ws'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.edit(f"""
**VMESS USER ONLINE**
{z}
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'login7-vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" UNLOCK LOGIN ","loginip7-vmess"),
Button.inline(" UNLOCK QUOTA ","logingb7-vmess")],
[Button.inline("‹ Back ›","vmess")]]
		await event.edit(buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" Trial ","trial7-vmess"),
Button.inline(" Create ","create7-vmess"),
Button.inline(" Login ","cek7-vmess")],
[Button.inline(" Delete ","delete7-vmess"),
Button.inline(" Unlock ","login7-vmess"),
Button.inline(" Limit ","limit7-vmess")],
[Button.inline(" Renew","renew7-vmess"),
Button.inline(" Restore ","restore7-vmess"),
Button.inline(" Akun ","akun7-vmess")],
[Button.inline("‹ BACK ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		vm = f' cat /etc/xray/config.json | grep "#vmg" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		msg = f"""
🧿───────────────────🧿
            **PANEL MENU VMESS**
🧿───────────────────🧿
` Total   :` `{vms.strip()}` __account__
` Host    :` `{DOMAIN}`
` ISP     :` `{z["isp"]}`
` Country :` `{z["country"]}`
🧿───────────────────🧿
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)